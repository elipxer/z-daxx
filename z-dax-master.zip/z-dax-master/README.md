# Z-Dax
NONE

Public z-dax a custom version of opendax

But if you dont have our Finex version you cant start it up

Custom images:
Finex | High perfomance matching engine for peatio |
Quantex | A liquidity bot support for Finex |
Applogic | Custom logic for peatio |


Command to fix ``sudo chmod -R 757 data/vault``
